package com.example.jpa.repository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.example.jpa.enity.Course;

import jakarta.persistence.EntityManager;

@Repository
@Transactional
public class CourseRepository 
{
	@Autowired
	EntityManager em1;
	
	public void saveOrUpdateCourse(Course course) {
		System.out.println("In the save Course method");
		if(course.getId() == 0)
			em1.persist(course);
		else
			em1.merge(course);
		System.out.println("Course persisted successfully in DB");
	}
	
	public Course getCourseById(int id) {
		Course course = em1.find(Course.class, id);
		return course;
	}
	
	public boolean deleteCourse(int id) {
		Course ct = getCourseById(id);
		em1.remove(ct);
		return true;
	}

}
